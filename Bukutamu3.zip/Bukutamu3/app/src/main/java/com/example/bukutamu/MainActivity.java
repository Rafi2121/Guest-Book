package com.example.bukutamu;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.infideap.atomic.Atom;
import com.infideap.atomic.FutureCallback;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.ed1)
    EditText editName;
    @BindView(R.id.ed2)
    EditText editNomer;
    @BindView(R.id.ed3)
    EditText editEmail;
    @BindView(R.id.ed4)
    EditText editinstansi;
    @BindView(R.id.ed5)
    EditText editsekolah;
    @BindView(R.id.rgasal)
    RadioGroup rgasal;
    @BindView(R.id.rbinstansi)
    RadioButton rbinstansi;
    @BindView(R.id.rbsekolah)
    RadioButton rbsekolah;
    @BindView(R.id.button2)
    Button btnSimpan;
    @BindView(R.id.ed6)
    EditText editkelas;
    @BindView(R.id.ed7)
    EditText editjurusan;
    @BindView(R.id.textView2)
    TextView text2;
    @BindView(R.id.textView3)
    TextView text3;
    @BindView(R.id.textView4)
    TextView text4;
    @BindView(R.id.textView5)
    TextView text5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        text2.setVisibility(View.GONE);
        text3.setVisibility(View.GONE);
        text4.setVisibility(View.GONE);
        text5.setVisibility(View.GONE);


        rbinstansi.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

         editinstansi.setVisibility(View.VISIBLE);
         editsekolah.setVisibility(View.GONE);
         editkelas.setVisibility(View.GONE);
         editjurusan.setVisibility(View.GONE);
         text2.setVisibility(View.VISIBLE);
         text3.setVisibility(View.GONE);
         text4.setVisibility(View.GONE);
         text5.setVisibility(View.GONE);

         }});

        rbsekolah.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
          editsekolah.setVisibility(View.VISIBLE);
          editkelas.setVisibility(View.VISIBLE);
          editjurusan.setVisibility(View.VISIBLE);
          editinstansi.setVisibility(View.GONE);
          text2.setVisibility(View.GONE);
          text3.setVisibility(View.VISIBLE);
          text4.setVisibility(View.VISIBLE);
          text5.setVisibility(View.VISIBLE);
          }});
    }

    @OnClick(R.id.button2)
    public void onViewClicked(){
        String name = editName.getText().toString();
        String email = editEmail.getText().toString();
        String nomer = editNomer.getText().toString();
        String instansi = editinstansi.getText().toString();
        String sekolah = editsekolah.getText().toString();
        String kelas = editkelas.getText().toString();
        String jurusan = editjurusan.getText().toString();
        String asal = "";

        int selectedId = rgasal.getCheckedRadioButtonId();
        if (selectedId == rbinstansi.getId()){
            asal = rbinstansi.getText().toString();
        } else if (selectedId == rbsekolah.getId()){
            asal = rbsekolah.getText().toString();
        } else {
            Toast.makeText(this, "Asal Belum dipilih", Toast.LENGTH_SHORT).show();
        }
        if (name.isEmpty()){
            editName.setError("Nama harus di isi");
        } else if (nomer.isEmpty()){
            editNomer.setError("Nomer  harus di isi");
        } else if (email.isEmpty()){
            editEmail.setError("E-mail harus di isi");
        } else {


            Atom.with(MainActivity.this)
                    .load("https://script.google.com/macros/s/AKfycbxYg7_pDUUILCkLoy1gkvlo3j25oOm7ipAb275L-g/exec")
                    .setMultipart("nama", name)
                    .setMultipart("email", email)
                    .setMultipart("nomer", nomer)
                    .setMultipart("asal", asal)
                    .setMultipart("instansi", instansi)
                    .setMultipart("sekolah", sekolah)
                    .setMultipart("kelas", kelas)
                    .setMultipart("jurusan", jurusan)
                    .as(ResponsInsert.class)
                    .setCallback(new FutureCallback<ResponsInsert>() {
                        @Override
                        public void onCompleted(Exception e, ResponsInsert result) {

                            if (e != null) {
                                e.printStackTrace();
                                return;
                            }

                            Log.d("Tag", "Status" + result.getStatus());
                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setMessage("Sukses Register");
                            builder.setTitle("Informasi Register");
                            builder.setCancelable(true);
                            builder.setIcon(R.drawable.ic_done_black_24dp);
                            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    finish();
                                    startActivity(getIntent());

                                }
                            });
                            builder.show();
                        }
                    });


        }
    }
}
